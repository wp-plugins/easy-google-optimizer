=== Easy Google Optimizer Plugin ===
Contributors: Adam Sayler

== Description ==

A plugin for integrating Google Website Optimizer into blog posts and pages. Please read the setup procedure for more info.

http://impressionengineers.com/wordpress/easy-google-optimizer-plugin/

Note: the system will currently only work with one Google Optimizer test per site.

== Installation ==

   1.  Unzip and upload the clickheat.php file into your `/wp-content/plugins/` directory
   2. Activate the plugin through the 'Plugins' menu in WordPress
   3. Follow the setup instructions to setup a Google Web Optimizer Test above
   4. Add the tracking code from Google into your test pages from the Easy Google Optimizer admin menu.  This can me found in the Manage > Easy Google Optimizer menu item (as of Wordpress 2.6 this is now under the Settings menu)
