<?php
/* 
Plugin Name: Easy Google Optimizer
Plugin URI: http://www.impressionengineers.com/wordpress/easy-google-optimizer-plugin/
Description: A plugin for integrating Google Website Optimizer into blog posts and pages. Please read the setup procedure for more info.
Version: 1.0
Author: Impression Engineers
Author URI: http://www.impressionengineers.com
 
Copyright (C) 2008 Adam Sayler, Impression Engineers.com

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
define('MYPLUGIN_URL', get_settings('siteurl') . '/wp-content/plugins/' . dirname(plugin_basename(__FILE__)));

if (!class_exists("DevloungePluginSeries")) {
	class DevloungePluginSeries {
		var $adminOptionsName = "DevloungePluginSeriesAdminOptions";
		function DevloungePluginSeries() { //constructor
			
		}
		function init() {
			$this->getAdminOptions();
		}
		//Returns an array of admin options
		function getAdminOptions() {
			$devloungeAdminOptions = array(
				'ego_enable' => 'true',
                		'ego_google_account' => 'XXXXXXX',
				'ego_google_test_id' => 'XXXXXX',
             			'ego_google_test_page_id' => '',
				'ego_google_control_page_id' => '',
				'ego_google_test_type' => '1',
          			'ego_google_convert_page_id' => '');
			
			$devOptions = get_option($this->adminOptionsName);

			if (!empty($devOptions)) {
				foreach ($devOptions as $key => $option) { $devloungeAdminOptions[$key] = $option;}
				update_option($this->adminOptionsName, $devloungeAdminOptions);
			} else {
				add_option($this->adminOptionsName, $devloungeAdminOptions);
			}					
			
			return $devloungeAdminOptions;
		}
		
		function addHeaderCode() {
			$devOptions = $this->getAdminOptions();
			if ($devOptions['ego_enable'] == "false") { return; }
		
			if (is_feed()) {
				return;
			}

			global $wp_query;
			$thePostID = $wp_query->post->ID;
		
			// 1 = A/B test
			// 2 = Multi-variant test

			$ego_test_page_check = explode(",", $devOptions['ego_google_control_page_id']);	

			echo "<!-- Start Of Easy Google Optimzer Header: Current Post = ". $thePostID ."-->";

			if(in_array($thePostID, $ego_test_page_check) && $devOptions['ego_google_test_type'] == '1') { ?>
			
<script>
function utmx_section(){}function utmx(){}(function(){var k='<?php echo $devOptions['ego_google_test_id']; ?>',d=document,l=d.location,c=d.cookie;function f(n){if(c){var i=c.indexOf(n+'=');if(i>-1){var j=c.indexOf(';',i);return c.substring(i+n.length+1,j<0?c.length:j)}}}var x=f('__utmx'),xx=f('__utmxx'),h=l.hash;d.write('<sc'+'ript src="'+'http'+(l.protocol=='https:'?'s://ssl':'://www')+'.google-analytics.com'+'/siteopt.js?v=1&utmxkey='+k+'&utmx='+(x?x:'')+'&utmxx='+(xx?xx:'')+'&utmxtime='+new Date().valueOf()+(h?'&utmxhash='+escape(h.substr(1)):'')+'" type="text/javascript" charset="utf-8"></sc'+'ript>')})();</script>
<script>utmx("url",'A/B');
</script>

	<?php }

			if(in_array($thePostID, $ego_test_page_check) && $devOptions['ego_google_test_type'] == '2') { ?>
<script>
function utmx_section(){}function utmx(){}(function(){var k='<?php echo $devOptions['ego_google_test_id']; ?>',d=document,l=d.location,c=d.cookie;function f(n){if(c){var i=c.indexOf(n+'=');if(i>-1){var j=c.indexOf(';',i);return c.substring(i+n.length+1,j<0?c.length:j)}}}var x=f('__utmx'),xx=f('__utmxx'),h=l.hash;d.write('<sc'+'ript src="'+'http'+(l.protocol=='https:'?'s://ssl':'://www')+'.google-analytics.com'+'/siteopt.js?v=1&utmxkey='+k+'&utmx='+(x?x:'')+'&utmxx='+(xx?xx:'')+'&utmxtime='+new Date().valueOf()+(h?'&utmxhash='+escape(h.substr(1)):'')+'" type="text/javascript" charset="utf-8"></sc'+'ript>')})();
</script>

<?php	} echo "<!-- End Of Easy Google Optimzer Header by Impression Engineers http://www.impressionengineers.com -->";		
		}

		function addFooterCode() {
			$devOptions = $this->getAdminOptions();
			if ($devOptions['ego_enable'] == "false") { return; }
		
			if (is_feed()) {
				return;
			}

			global $wp_query;
			$thePostID = $wp_query->post->ID;
		
			// 1 = A/B test
			// 2 = Multi-variant test

			$ego_test_page_check = $devOptions['ego_google_control_page_id'];	// add the control page ID to the list for checking
			$ego_test_page_check .= ",".$devOptions['ego_google_test_page_id'];	// add the test page IDs to the list for checking
			$ego_test_page_check = explode(",", $ego_test_page_check);		// makes an array for checking

			$ego_convert_page_check = $devOptions['ego_google_convert_page_id'];	// add the conversion page ID to the list for checking
			$ego_convert_page_check = explode(",", $ego_convert_page_check);	// makes an array for checking

			echo "<!-- Start Of Easy Google Optimzer Footer: Current Post = ". $thePostID ."-->";

		// test to see if this is a control or testing page
			if(in_array($thePostID, $ego_test_page_check)) { ?>

	<script>if(typeof(urchinTracker)!='function')
	document.write('<sc'+'ript src="'+'http'+(document.location.protocol=='https:'?'s://ssl':'://www')+'.google-analytics.com/urchin.js'+'"></sc'+'ript>')</script>
	<script>
	_uacct = '<?php echo $devOptions['ego_google_account']; ?>';
	urchinTracker("/<?php echo $devOptions['ego_google_test_id']; ?>/test");
	</script>
			<?php }

		// test to see if this is a conversion page

			if(in_array($thePostID, $ego_convert_page_check)) { ?>

	<script>if(typeof(urchinTracker)!='function')
	document.write('<sc'+'ript src="'+'http'+(document.location.protocol=='https:'?'s://ssl':'://www')+'.google-analytics.com/urchin.js'+'"></sc'+'ript>')</script>
	<script>
	_uacct = '<?php echo $devOptions['ego_google_account']; ?>';
	urchinTracker("/<?php echo $devOptions['ego_google_test_id']; ?>/goal");
	</script>
			
			<?php }
			echo "<!-- End Of Easy Google Optimzer Footer by Impression Engineers http://www.impressionengineers.com -->";		
		}
		

		//Prints out the admin page
		function printAdminPage() {
			$devOptions = $this->getAdminOptions();
										
			if (isset($_POST['update_EGOPluginSettings'])) { 
						
	// updates all the admin page entries if posted
	if (isset($_POST['ego_enable'])) {$devOptions['ego_enable'] = $_POST['ego_enable'];}

	if (isset($_POST['ego_google_account'])) {$devOptions['ego_google_account'] = $_POST['ego_google_account'];}

	if (isset($_POST['ego_google_test_id'])) {$devOptions['ego_google_test_id'] = $_POST['ego_google_test_id'];}

	if (isset($_POST['ego_google_test_page_id'])) {$devOptions['ego_google_test_page_id'] = $_POST['ego_google_test_page_id'];}	

	if (isset($_POST['ego_google_control_page_id'])) {$devOptions['ego_google_control_page_id'] = $_POST['ego_google_control_page_id'];}

	if (isset($_POST['ego_google_test_type'])) {$devOptions['ego_google_test_type'] = $_POST['ego_google_test_type'];}	

	if (isset($_POST['ego_google_convert_page_id'])) {$devOptions['ego_google_convert_page_id'] = $_POST['ego_google_convert_page_id'];}
	
	foreach ($devOptions as $key => $option) { $devloungeAdminOptions[$key] = $option;}
	update_option($this->adminOptionsName, $devloungeAdminOptions);
							
	?>
<div class="updated"><p><strong><?php _e("Settings Updated.", "DevloungePluginSeries");?></strong></p></div>
					
	<?php } ?>

<div class=wrap>
<form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
<h2>Easy Google Optimizer Plugin</h2>

<h3>Enable Easy Google Optimizer?</h3>
<p>Selecting "No" will disable the Google Optimizer tests.</p>
<p><label for="ego_enable-1">
<input type="radio" id="ego_enable-1" name="ego_enable" value="true" <?php if ($devOptions['ego_enable'] == "true") { _e('checked="checked"', "dl_pluginSeries"); }?> /> Yes</label>
&nbsp;&nbsp;&nbsp;&nbsp;
<label for="ego_enable-2">
<input type="radio" id="ego_enable-2" name="ego_enable" value="false" <?php if ($devOptions['ego_enable'] == "false") { _e('checked="checked"', "dl_pluginSeries"); }?>/> No</label></p>

<p> Note: the system will currently only work with one Google Optimizer test per site</p>

<?php if ($devOptions['ego_enable'] == "true") { ?>

<h2>How to setup this plugin</h2>
<p>When setting up a Google Optimzer test you will be given code blocks that you will be asked to paste into your website code. This plugin is designed to do the heavy lifting for you but we need to know your Google account ID and the test ID so we can properly setup your pages for testing. In this screen shot you will see a sample of what we are looking for.</p>
<p><img src="<?php echo MYPLUGIN_URL; ?>/setup.gif" border="0" width="618" height="122"></p>

<p>Specific instructions on how to setup each test is available in a <a href="http://www.google.com/intl/en/websiteoptimizer/tutorials.html">video tutorial here</a></p>

<h3>What is the Google Optimizer account ID? (Item 1 in red)</h3>
<p><label for="ego_google_account">
<input type="text" id="ego_google_account" name="ego_google_account" value="<?php _e(apply_filters('format_to_edit',$devOptions['ego_google_account']), 'dl_pluginSeries') ?>"></label></p>

<h3>What type of test will you be preforming?</h3>
<p>Google offers two kinds of tests. An A/B test that will test two different page layouts. Or a multi-variant test that will test certain items inside a given page.</p>
<p>Please note that multi-variant tests are perfomred inside the main control page and are not used to test completely separate page layouts.</p>
<p><label for="ego_google_test_type-1">
<input type="radio" id="ego_google_test_type-1" name="ego_google_test_type" value="1" <?php if ($devOptions['ego_google_test_type'] == "1") { _e('checked="checked"', "dl_pluginSeries"); }?> /> AB test</label>
&nbsp;&nbsp;&nbsp;&nbsp;
<label for="ego_google_test_type-2">
<input type="radio" id="ego_google_test_type-2" name="ego_google_test_type" value="2" <?php if ($devOptions['ego_google_test_type'] == "2") { _e('checked="checked"', "dl_pluginSeries"); }?>/> Multi-Variant</label></p>

<h3>What is the test ID for these page  (Item 2 in blue)</h3>
<p><label for="ego_google_test_id">
<input type="text" id="ego_google_test_id" name="ego_google_test_id" value="<?php _e(apply_filters('format_to_edit',$devOptions['ego_google_test_id']), 'dl_pluginSeries') ?>"></label></p>

<h2>Please tell us what pages you want to test. </h2>
<p>If you can't easily find the post ID of the pages you are wanting to test we have included a handy reference for you. Visit the web page you want to test. View the source code and look for our HTML comment tag that says "Start of Easy Google Optimzer".  Inside the comment you will find the current page post ID in the Wordpress system.  Use these post ID numbers in the remaining sections.</p>
<p><img src="<?php echo MYPLUGIN_URL; ?>/setup2.gif" border="0" width="494" height="52"></p>

<h3>Please list the main test control page</h3>
<p>This is the main landing page for your test. All variations will start at this page.</p>
<p><label for="ego_google_control_page_id">
<input type="text" id="ego_google_control_page_id" name="ego_google_control_page_id" value="<?php _e(apply_filters('format_to_edit',$devOptions['ego_google_control_page_id']), 'dl_pluginSeries') ?>"></label></p>

<h3>Please list any A/B alternate version test pages</h3>
<p>The control page will always be tested.  However, in A/B tests there are usually additional pages being tested.  Please list the Post IDs of those pages here separated with commas</p>
<p><label for="ego_google_test_page_id">
<input type="text" id="ego_google_test_page_id" name="ego_google_test_page_id" value="<?php _e(apply_filters('format_to_edit',$devOptions['ego_google_test_page_id']), 'dl_pluginSeries') ?>"></label></p>

<h3>Please list the goal page(s) you want to include in the test</h3>
<p>Visits to these pages tell the Google system a successful conversion has occurred. Please list the Post IDs of those pages here separated with commas </p>
<p><label for="ego_google_convert_page_id">
<input type="text" id="ego_google_convert_page_id" name="ego_google_convert_page_id" value="<?php _e(apply_filters('format_to_edit',$devOptions['ego_google_convert_page_id']), 'dl_pluginSeries') ?>"></label></p>
<?php } ?>

<div class="submit">
<input type="submit" name="update_EGOPluginSettings" value="<?php _e('Update Settings', 'dl_pluginSeries') ?>" /></div>
</form>
<div style="border: 1px solid #CCC; margin: 5px; padding: 5px; ">
<p>If you found this plugin useful I would always appreciate some link love. <a href="http://www.impressionengineers.com/wordpress/easy-google-optimizer-plugin/">Our Plugin Home Page</a> <br/>Or you can buy me a virtual beer
<form action="https://www.paypal.com/cgi-bin/webscr" method="post" style="margin: 0; padding:0;">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="image" src="https://www.paypal.com/en_US/i/btn/btn_donate_SM.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1">
<input type="hidden" name="encrypted" value="-----BEGIN PKCS7-----MIIHZwYJKoZIhvcNAQcEoIIHWDCCB1QCAQExggEwMIIBLAIBADCBlDCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20CAQAwDQYJKoZIhvcNAQEBBQAEgYA8RUqjhDrpTelgBbMPSzvxztfTzm0EI5cjERUo6gj22vV6x5VD4S4xRP/Ha4yX2zau9o3OKJkHtNW4BidBgYQ3jwaN+ecFew7+U4PStfLDMsTkh7QmECQCY8q42K+uiVIwM1Au2AbGlE+7Ay5htsY6b445MpRqpGfyZbKL/ypzhTELMAkGBSsOAwIaBQAwgeQGCSqGSIb3DQEHATAUBggqhkiG9w0DBwQIMLLQ+JLxuv6AgcCzw6EjM70qCCSSlOuvfWwGze/9L4W66KRO5a/YjVZa1WCzsQxMpXipCoqz7H5vGogqn65zaX4jPbViavGRuR72P53nKFugNWDk+ZFabDlxgB7ljnBpeMUBHmmtw3Vg2t/XGVVxIR5j+UydcXrz0qU+qv4pFWKuoSiX3M1WbyTWxgf9DSX9dK3SRw3v1nMhiEG8LQGIFp8J8y4yNzajQDlwyVOf+mVJW9zZ5oajBGdoz9DQIfdwxsfda/K3tfyPFwWgggOHMIIDgzCCAuygAwIBAgIBADANBgkqhkiG9w0BAQUFADCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20wHhcNMDQwMjEzMTAxMzE1WhcNMzUwMjEzMTAxMzE1WjCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20wgZ8wDQYJKoZIhvcNAQEBBQADgY0AMIGJAoGBAMFHTt38RMxLXJyO2SmS+Ndl72T7oKJ4u4uw+6awntALWh03PewmIJuzbALScsTS4sZoS1fKciBGoh11gIfHzylvkdNe/hJl66/RGqrj5rFb08sAABNTzDTiqqNpJeBsYs/c2aiGozptX2RlnBktH+SUNpAajW724Nv2Wvhif6sFAgMBAAGjge4wgeswHQYDVR0OBBYEFJaffLvGbxe9WT9S1wob7BDWZJRrMIG7BgNVHSMEgbMwgbCAFJaffLvGbxe9WT9S1wob7BDWZJRroYGUpIGRMIGOMQswCQYDVQQGEwJVUzELMAkGA1UECBMCQ0ExFjAUBgNVBAcTDU1vdW50YWluIFZpZXcxFDASBgNVBAoTC1BheVBhbCBJbmMuMRMwEQYDVQQLFApsaXZlX2NlcnRzMREwDwYDVQQDFAhsaXZlX2FwaTEcMBoGCSqGSIb3DQEJARYNcmVAcGF5cGFsLmNvbYIBADAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBBQUAA4GBAIFfOlaagFrl71+jq6OKidbWFSE+Q4FqROvdgIONth+8kSK//Y/4ihuE4Ymvzn5ceE3S/iBSQQMjyvb+s2TWbQYDwcp129OPIbD9epdr4tJOUNiSojw7BHwYRiPh58S1xGlFgHFXwrEBb3dgNbMUa+u4qectsMAXpVHnD9wIyfmHMYIBmjCCAZYCAQEwgZQwgY4xCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLUGF5UGFsIEluYy4xEzARBgNVBAsUCmxpdmVfY2VydHMxETAPBgNVBAMUCGxpdmVfYXBpMRwwGgYJKoZIhvcNAQkBFg1yZUBwYXlwYWwuY29tAgEAMAkGBSsOAwIaBQCgXTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0wODA5MjEyMTIzNTRaMCMGCSqGSIb3DQEJBDEWBBSlWo3lvRJIzX/G3tXdHd7FoL81UjANBgkqhkiG9w0BAQEFAASBgLewsFmcqb0Bv0TqBMzRyp9EPqjLafQOU6POwUWCkLiUlZB4U6DfpKBE/DIriQu6eSxQ82RAgXWGmWoaCUnPn+2at6CMORImRrOyLVQvCLOSUYeRQ/sxSZJNDK+09FY1T82lwcE/U7jGEGnk0IJm/J4ZNIUhVUOXTKgv8EQQWP6H-----END PKCS7-----
">
</form> Either way I would appreciate any support you can give.</p>
</div>

 </div>
					<?php
				}//End function printAdminPage()
	
	}

} //End Class DevloungePluginSeries

if (class_exists("DevloungePluginSeries")) {
	$dl_pluginSeries = new DevloungePluginSeries();
}

//Initialize the admin panel
if (!function_exists("DevloungePluginSeries_ap")) {
	function DevloungePluginSeries_ap() {
		global $dl_pluginSeries;
		if (!isset($dl_pluginSeries)) {
			return;
		}
		if (function_exists('add_options_page')) {
	add_options_page('Easy Google Optimzer', 'Easy Google Optimizer', 9, basename(__FILE__), array(&$dl_pluginSeries, 'printAdminPage'));
		} 
	}	
}

//Actions and Filters	
if (isset($dl_pluginSeries)) {
	//Actions
	add_action('admin_menu', 'DevloungePluginSeries_ap');
	add_action('wp_head', array(&$dl_pluginSeries, 'addHeaderCode'), 1);
	add_action('wp_footer', array(&$dl_pluginSeries, 'addFooterCode'), 1);
	add_action('activate_devlounge-plugin-series/devlounge-plugin-series.php',  array(&$dl_pluginSeries, 'init'));
}

?>